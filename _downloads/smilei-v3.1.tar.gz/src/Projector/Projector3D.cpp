#include "Projector3D.h"

#include "Params.h"
#include "Patch.h"

Projector3D::Projector3D(Params &params, Patch* patch)
  : Projector(params, patch)
{
}

